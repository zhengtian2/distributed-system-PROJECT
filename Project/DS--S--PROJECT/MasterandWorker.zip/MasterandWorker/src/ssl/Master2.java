package ssl;


import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.SocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;


public class Master2 implements Runnable
{
	 private   String DEFAULT_HOST  = "115.146.86.185";  
	 private   int    DEFAULT_PORT = 5000; 
	 private static String[] oneAddressAndPort=null;//nnnn
	 private static String srvKeystorePath="/users/zheng/desktop/download/";//server key store
	 private static String clientKeystorePath="/Users/zheng/Desktop/download/cer/";//client keystore
	 private String JarfilePath="/Users/zheng/Desktop/GetinputfileCmd.jar";//path of jar file
	 private String InputFilePath="/Users/zheng/Desktop/movetotrash/output.txt";//Path of input file
	 private String OutputFilePath="/Users/zheng/Desktop";//GUI path of output file
	 private String newDeadline;
	 public String status="";
	 private SSLSocket  sslSocket;  
	 public Master2(String a,String b,String c)
	 {JarfilePath=a;
	 InputFilePath=b;
	 OutputFilePath=c;
	 }
	 public Master2(String a,String b,String c,String ip,int port)
	 {JarfilePath=a;
	 InputFilePath=b;
	 OutputFilePath=c;
	 DEFAULT_HOST=ip;
	 DEFAULT_PORT=port;
	 
	 }
	 public Master2(String a,String b,String c,String ip,int port, String d)
	 {JarfilePath=a;
	 InputFilePath=b;
	 OutputFilePath=c;
	 DEFAULT_HOST=ip;
	 DEFAULT_PORT=port;
	 newDeadline = d;
	 }
	 public Master2(){}// empty constructor
	 // initiate method
	  public void init()
	  { 
		  	// You can hardcode the values of the JVM variables as follows:
		  System.setProperty("javax.net.ssl.trustStore", srvKeystorePath+"WorkerKey");
			System.setProperty("javax.net.ssl.trustStorePassword","123456");
		  	System.setProperty("javax.net.ssl.keyStore",clientKeystorePath+"myClienKeystore");
			System.setProperty("javax.net.ssl.keyStorePassword","123456");
			
			// Create SSL socket factory, which creates SSLSocket instances
			SocketFactory factory= SSLSocketFactory.getDefault();
			try {
			//  Use the factory to instantiate SSLSocket
				System.out.println("Creating connection to host:"+DEFAULT_HOST);
				sslSocket = (SSLSocket)factory.createSocket(DEFAULT_HOST, DEFAULT_PORT);
				System.out.println("Connection has been established,transferring file...");
		
	  } catch (UnknownHostException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}
	
	  }
	 // main method 
	  public static void main(String args[]) throws InterruptedException
	  {
		  Master2 m=new Master2();
		  Thread t= new Thread(m);
		  t.start();
		 // t.join();	  		  
	  }
	/*****
	 * run()
	 * 
	 * 
	 * *****/
	  public void run()
	  {
		  init();
		  process(JarfilePath,InputFilePath,OutputFilePath);	
		  }
	
	  
	  public void process(String JarfilePath, String InputFilePath, String OutputFilePath)
	  {
		  int length=0;
		  try {
			  status="Sending";
	          OutputStream output = sslSocket.getOutputStream();  
	          DataOutputStream dos=new DataOutputStream(output);
	          DataInputStream dis=new DataInputStream(sslSocket.getInputStream());
	          //****transfer jar file
	           File file=new File(JarfilePath);//jar file get the path from GUI
	           String filename=file.getName();
	           FileInputStream fIn = new FileInputStream(file);         
		          String fileSize;
		          fileSize=fIn.available()+"";
					//System.out.println("fileSize====>"+fileSize);
		          dos.writeUTF(fileSize);
		          dos.flush();
		          dos.writeUTF(file.getName());
		          dos.flush();
	           byte[] sendBytes = new byte[1024];        
	           while ((length = fIn.read(sendBytes, 0, sendBytes.length)) > 0) {
	        	   //System.out.println(length);
                   dos.write(sendBytes, 0, length);
                  // dos.flush();
               }
		          System.out.println("jar file "+filename+"  has been transfered...");

	           
	           //transfer input file
	         file=new File(InputFilePath);//get the input file path...
	          fIn = new FileInputStream(file);         
	           fileSize=null;
	          fileSize=fIn.available()+"";
				//System.out.println("fileSizeOfInputfile is====>"+fileSize);

	          dos.writeUTF(fileSize);
	          dos.flush();
	          filename=file.getName();
	          dos.writeUTF(filename);
	          dos.flush();
          while ((length = fIn.read(sendBytes, 0, sendBytes.length)) > 0) {
       	  // System.out.println(length);
              dos.write(sendBytes, 0, length);
          }
          System.out.println("input file  "+filename+"  has been transfered...");
          status="Processing";
          System.out.println("Processing please wait....");
          
          //transfer deadline
         // dos.writeUTF(this.newDeadline);
	         //get the output file 
          		
	            dis=new DataInputStream(sslSocket.getInputStream());
	           fileSize=dis.readUTF();
	        
	           File fileResult =new File(OutputFilePath+"/receiveOput.txt");//the path should be specified by the user from the GUI
	           System.out.println("Output File has been generated...");
	           status="Finished";


	           FileOutputStream fos =new FileOutputStream(fileResult);
	           byte[] result=new byte[1024];
	           length=0;
	          int sizeCounter=0;
	           while((length=dis.read(result,0,result.length))>0)
	           {	          sizeCounter+=length;

	        	   fos.write(result, 0, length);
	        	   fos.flush();
	        	   if(fileSize.equals(Integer.toString(sizeCounter)))
	        	   {
	        		   break;
	        	   }
	           }
	           fos.close();
	           dis.close();
	           fIn.close();
	           output.close();
	           sslSocket.close();
	           
System.out.println("output  has been saved to "+OutputFilePath);

		} catch (Exception e) {
			e.printStackTrace();
		}  

	  }
	  
	  
	 /* public String getJobStatus(String s)
	  {
		  String status=s;
		  return status;
	  }*/
	  
	
	  public boolean connectWorker(String a[])
	  {
		  try {
		  String Ip=a[0];
		  int port=Integer.parseInt(a[1]);
		  System.setProperty("javax.net.ssl.trustStore", srvKeystorePath+"WorkerKey");
			System.setProperty("javax.net.ssl.trustStorePassword","123456");
		  	System.setProperty("javax.net.ssl.keyStore",clientKeystorePath+"myClienKeystore");
			System.setProperty("javax.net.ssl.keyStorePassword","123456");
			
			// Create SSL socket factory, which creates SSLSocket instances
			SocketFactory factory= SSLSocketFactory.getDefault();
			
			//  Use the factory to instantiate SSLSocket
				System.out.println("Creating connection to host:"+Ip);
				sslSocket = (SSLSocket)factory.createSocket(Ip, port);

				System.out.println("Connection has been established,transferring file...");
				


	  } catch (IOException e) {
		e.printStackTrace();
	}return sslSocket.isBound();
	  }
	  public void connectWorker(String a[][])
	  {
		  for(int i=0; i<a.length;i++){
			  oneAddressAndPort= a[i];
			  String Ip=oneAddressAndPort[0];
			  int port=Integer.parseInt(oneAddressAndPort[1]);
			  System.setProperty("javax.net.ssl.trustStore", srvKeystorePath+"WorkerKey");
				System.setProperty("javax.net.ssl.trustStorePassword","123456");
			  	System.setProperty("javax.net.ssl.keyStore",clientKeystorePath+"myClienKeystore");
				System.setProperty("javax.net.ssl.keyStorePassword","123456");
				
				// Create SSL socket factory, which creates SSLSocket instances
				SocketFactory factory= SSLSocketFactory.getDefault();
				try {
				//  Use the factory to instantiate SSLSocket
					System.out.println("Creating connection to host:"+Ip);
					sslSocket = (SSLSocket)factory.createSocket(Ip, port);
					System.out.println("Connection has been established,transferring file...");
			
		  } catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		  		
		
	  } 
	  }
	 
}